package br.com.lojamodel.dao.impl;

import java.util.List;

import br.com.lojamodel.Contato;
import br.com.lojamodel.dao.DAO;

public class ContatoDAO implements DAO {

	@Override
	public void create(Object object) {
		Contato contato = (Contato) object;

	}

	@Override
	public List<Object> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Object object) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Object object) {
		// TODO Auto-generated method stub

	}

}
