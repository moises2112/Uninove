package br.com.lojamodel.daogeneric;

import java.sql.PreparedStatement;
import java.util.Calendar;
import java.util.List;

public class DAOGenericJDBC<T> implements DAO<T>  {

	@Override
	public void inserir(T t) {
		
	}

	@Override
	public void remover(T t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(T t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<T> buscar(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<T> buscarTodos(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
