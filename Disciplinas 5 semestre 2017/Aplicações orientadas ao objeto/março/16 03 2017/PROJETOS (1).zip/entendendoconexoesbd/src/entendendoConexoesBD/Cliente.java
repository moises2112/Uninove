package entendendoConexoesBD;

import java.util.List;

public class Cliente {
	
	Long id;
	
	String nome;
	
	List<Contato> contatos;
}
