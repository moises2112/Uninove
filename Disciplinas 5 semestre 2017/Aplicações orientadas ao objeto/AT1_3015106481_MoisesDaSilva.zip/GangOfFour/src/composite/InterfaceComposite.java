package composite;

public interface InterfaceComposite {
	
	public long getTamanho();
		
	
}
