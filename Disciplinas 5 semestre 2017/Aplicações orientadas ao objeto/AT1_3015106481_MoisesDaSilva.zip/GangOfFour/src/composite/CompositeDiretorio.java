package composite;

import java.util.ArrayList;
import java.util.List;

public class CompositeDiretorio implements InterfaceComposite {
	
	public List<CompositeArquivo> arquivos = new ArrayList<CompositeArquivo>();
	@Override
	public long getTamanho() {
		
		return arquivos.size();
	}

}
