package composite;

import java.util.Random;

public class CompositeArquivo implements InterfaceComposite{
	
	
	long tamanho;
	
	@Override
	public long getTamanho() {
		Random random = new Random();
		tamanho = (long)random.nextInt(10)+1;
		return tamanho;
	}
	
}
