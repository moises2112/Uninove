

import composite.CompositeArquivo;
import composite.CompositeDiretorio;
import factoryMethod.FactoryMethod;
import singleton.Singleton;

public class TesteExemplos {
	public static void main(String[] args) {
		//Exemplo Singleton
		Singleton singleton = new Singleton();
		singleton.singletonConnection();
		
		//Exemplo FactoryMethod
		FactoryMethod factorymethod = new FactoryMethod();
		factorymethod.factoryMethodConnection();
		
		//Exemplo Composite
		CompositeArquivo arquivo1 = new CompositeArquivo();
		CompositeArquivo arquivo2 = new CompositeArquivo();
		CompositeArquivo arquivo3 = new CompositeArquivo();
		CompositeDiretorio diretorio = new CompositeDiretorio();
		diretorio.arquivos.add(arquivo1);
		diretorio.arquivos.add(arquivo2);
		diretorio.arquivos.add(arquivo3);
		System.out.println("Exemplo Composite");
		System.out.println("Tamanho do arquivo:"+arquivo1.getTamanho());
		System.out.println("Tamanho do diret�rio:"+diretorio.getTamanho()+"\n\n");
		
		
	}

}
