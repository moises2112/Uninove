package factoryMethod;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FactoryMethod {
	
	public static Connection factoryMethodConnection(){
		//Exemplo FactoryMethod
		String stringDeConexao = "jdbc:h2:C:/Users/moise/Desktop/Projetos/GangOfFour/bancodedados/db";
		String usuario = "sa";
		String senha ="";
		
		Connection conexao = null;
		try {
			System.out.println("Exemplo Factory Method");
			System.out.println("Conectando...");
			conexao = DriverManager.getConnection(stringDeConexao, usuario, senha);
			System.out.println("Conectado\n\n\n");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return conexao;
	
	
	}
	
}
