package singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Singleton {
	private static Connection conection;


	public static Connection singletonConnection() {
		//Exemplo de Singleton
		if (conection == null) {
			try {
				System.out.println("Exemplo Singleton");
				System.out.println("Conectando...");
				conection = DriverManager.getConnection("jdbc:h2:C:/Users/moise/Desktop/Projetos/GangOfFour/bancodedados/db", "sa",
						"");
				
				System.out.println("Conectado\n\n\n");
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return conection;
	}

	
}
